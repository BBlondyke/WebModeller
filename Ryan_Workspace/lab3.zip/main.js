/*
Ryan Connors
1344722
rmconnor@ucsc.edu
UCSC CMPS 160
Lab 3, Shaded Mandelbrot
 */


//global level variables
var mSet;
var rMax;
var MAX_HEIGHT;
var left;
var right;
var bottom;
var topVal;
var baseline_Mandel;
var xDim;
var yDim;
var MAX_YDIM;
var MAX_XDIM;
var MAX_POINTS;

//DOM
var canvas;

//scale variables
var scaleX;
var scaleY;
var scaleZ;

//shaders and gl
var vShader;
var fShader;
var program;
var gl;

//buffers
var vBuffer;
var cBuffer;
var vPosition;
var vColor;
var vNormal;
var nBuffer;



/*
 * Shader Function
 */

function initShaders(gl, vShaderName, fShaderName) {
    function getShader(gl, shaderName, type) {
    	//createShader instantiates the wrap used during glsl compilation.
        var shader = gl.createShader(type),
            shaderScript = shaderName;
        if (!shaderScript) {
            alert("Could not find shader source: "+shaderName);
        }
        //gl.shaderSource links a shader source to the already created shader wrapper.
        gl.shaderSource(shader, shaderScript);
        //compile shader will actually compile the provided string glsl block
        gl.compileShader(shader);

		//getShaderParameter in this case is checking the ensure the compilation
		//of the shaders went off without a hitch
        if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
            alert(gl.getShaderInfoLog(shader));
            return null;
        }
        return shader;
    }
    
    var vertexShader = getShader(gl, vShaderName, gl.VERTEX_SHADER),
        fragmentShader = getShader(gl, fShaderName, gl.FRAGMENT_SHADER),
        //createProgram generates a program object that will store the compiled shader information
        program = gl.createProgram();

	//attach shader attached the compiled gl shader code to its program object container
    gl.attachShader(program, vertexShader);
    gl.attachShader(program, fragmentShader);
    //link program links all of the components including the compiled shader code together.
    gl.linkProgram(program);

	//getProgramParameter in this case is checking to ensure the linking went off properly
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
        alert("Could not initialise shaders");
        return null;
    }

    
    return program;
};

/*
 * Complex class representing a complex number
 */
function Complex() {
	this.rComp = 0.0;
	this.iComp = 0.0;
	
	this.add = function(operand) {
		var rtn = new Complex();
		
		rtn.rComp = this.rComp + operand.rComp;
		rtn.iComp = this.iComp + operand.iComp;
		return rtn;
	}
	
	this.mult = function(operand) {
		var rtn = new Complex();
		
		rtn.rComp = ((this.rComp * operand.rComp) - (this.iComp * operand.iComp));
		rtn.iComp = ((this.rComp * operand.iComp) + (this.iComp * operand.rComp));
		
		return rtn;
	}
	
	this.modSquare = function() {
		return (Math.pow(this.rComp, 2) + Math.pow(this.iComp, 2));
	}
	
	this.copy = function() {
		var rtn = new Complex();
		rtn.rComp = this.rComp
		rtn.iComp = this.iComp;
		
		return rtn;
	}
}

/*
 * Transformation Support Functions
 * 
 * This all return arrays that can be used to populate the matrix classes
 * and then perform easy operations prior to setting the gl uniform matrix
 */

function makeTranslation2D(deltaX, deltaY) {
	return [
	1.0, 	0.0, 	0.0,
	0.0, 	1.0, 	0.0,
	deltaX, deltaY, 1.0
	];
}

function makeRotation2D(angle) {
	var cos = Math.cos(angle);
	var sin = Math.sin(angle);
	
	return [
		cos,	-1 * sin,	0.0,
		sin,	cos,		0.0,
		0.0,	0.0,		1.0
	];
	
}

function makeScale2D(scaleX, scaleY) {
	return [
		scaleX, 	0.0,	 0.0,
		0.0,		scaleY,  0.0,
		0.0,		0.0	,	 1.0
	];
}

function makeTranslation3D(deltaX, deltaY, deltaZ) {
	return [
		1.0, 	0.0, 	0.0,	0.0,
		0.0, 	1.0, 	0.0,	0.0,
		0.0,	0.0,	1.0,	0.0,
		deltaX,	deltaY,	deltaZ, 1.0
	];
}

function makeRotation3DX(angle) {
	
	var cos = Math.cos(angle);
	var sin = Math.sin(angle);
	
	return [
		1.0,	0.0,	0.0,	0.0,
		0.0,	cos,	sin,	0.0,
		0.0,	-1*sin,	cos,	0.0,
		0.0,	0.0,	0.0,	1.0
	];
}

function makeRotation3DY(angle) {
	var cos = Math.cos(angle);
	var sin = Math.sin(angle);
	
	return [
		cos,	0.0,	-1*sin,		0.0,
		0.0,	1.0,	0.0,		0.0,
		sin,	0.0,	cos,		0.0,
		0.0,	0.0,	0.0,		1.0
	];
}

function makeRotation3DZ(angle) {
	var cos = Math.cos(angle);
	var sin = Math.sin(angle);
	return [
		cos,	sin,	0.0,	0.0,
		-1*sin, cos,	0.0,	0.0,
		0.0,	0.0,	1.0,	0.0,
		0.0,	0.0,	0.0,	1.0
	];
}

function makeScale3D(scaleX, scaleY, scaleZ) {
	return [
		scaleX, 0.0,	0.0,	0.0,
		0.0,	scaleY, 0.0,	0.0,
		0.0,	0.0,	scaleZ,	0.0,
		0.0,	0.0,	0.0,	1.0
	];
}

/*
 * Vector class representing a 3 dimensional vector in space
 * 
 */
function Vector(x, y, z) {
	this.x = x;
	this.y = y;
	this.z = z;
	
	this.add = function(vector) {
		var rtn = new Vector(0.0, 0.0, 0.0);
		rtn.x = this.x + vector.x;
		rtn.y = this.y + vector.y;
		rtn.z = this.z + vector.z;
		
		return rtn;
	}
	
	this.scale = function(scalar) {
		this.x = this.x * scalar;
		this.y = this.y * scalar;
		this.z = this.z * scalar;
	}
	
	this.scalarMult = function(scalar) {
		var rtn = new Vector(this.x, this.y, this.z);
		rtn.x = rtn.x * scalar;
		rtn.y = rtn.y * scalar;
		rtn.z = rtn.z * scalar;
		
		return rtn;
	}
	
	this.dotProduct = function( vector ) {
		return (this.x * vector.x + this.y * vector.y + this.z * vector.z);
	}
	
	this.crossProduct = function(vector) {
		//use sarrus rule
		var rtn = new Vector();
		rtn.x = (this.y * vector.z - this.z * vector.y);
		rtn.y = (this.z * vector.x - this.x * vector.z);
		rtn.z = (this.x * vector.y - this.y * vector.x);
		return rtn;
	}
	
	this.copy = function() {
		var rtn = new Vector(this.x, this.y, this.z);
		return rtn;
	}
	
	this.toFloat32Array = function() {
		return new Float32Array([
			this.x,
			this.y,
			this.z
		]);
	}
	
}

/*
 * Vector4D, its like a vector3D but with a fourth dimension.
 * 
 * 
 */
function Vector4D(x, y, z, w) {
	this.x = x;
	this.y = y;
	this.z = z;
	this.w = w;
	
	this.add = function(vector) {
		var rtn = new Vector4D(0.0, 0.0, 0.0, 0.0);
		rtn.x = this.x + vector.x;
		rtn.y = this.y + vector.y;
		rtn.z = this.z + vector.z;
		rtn.w = this.w + vector.w;
		
		return rtn;
	}
	
	this.scale = function(scalar) {
		this.x = this.x * scalar;
		this.y = this.y * scalar;
		this.z = this.z * scalar;
		this.w = this.w * scalar;
	}
	
	this.scalarMult = function(scalar) {
		var rtn = new Vector4D(this.x, this.y, this.z, this.w);
		rtn.x = rtn.x * scalar;
		rtn.y = rtn.y * scalar;
		rtn.z = rtn.z * scalar;
		rtn.w = rtn.w * scalar;
		
		return rtn;
	}
	
	this.dotProduct = function( vector ) {
		return (this.x * vector.x + this.y * vector.y + this.z * vector.z + this.w * vector.w);
	}
	
	this.copy = function() {
		var rtn = new Vector4D(this.x, this.y, this.z, this.w);
		return rtn;
	}
	
	this.toFloat32Array = function() {
		return new Float32Array([
			this.x,
			this.y,
			this.z,
			this.w
		]);
	}
	
}


/*
 * Matrix Classes
 * 
 * this contain support functions for operations on matrices
 */

function Matrix3D() {
	
	this.x = new Vector(0.0, 0.0, 0.0);
	this.y = new Vector(0.0, 0.0, 0.0);
	this.z = new Vector(0.0, 0.0, 0.0);
	
	this.populateFromArray = function( array ) {
		this.x = new Vector(array[0], array[1], array[2]);
		this.y = new Vector(array[3], array[4], array[5]);
		this.z = new Vector(array[6], array[7], array[8]);
	}
	
	this.rowVecMult = function(vector) {
		
		var rtn = new Vector( 0.0, 0.0, 0.0);
		
		rtn.x = ( vector.x * this.x.x + vector.y * this.y.x + vector.z * this.z.x );
		rtn.y = ( vector.x * this.x.y + vector.y * this.y.y + vector.z * this.z.y );
		rtn.z = ( vector.x * this.x.z + vector.y * this.y.z + vector.z * this.z.z );
		
		return rtn;
	}
	
	this.colVecMult = function(vector) {
		
		return new Vector(this.x.dotProduct(vector),
							 this.y.dotProduct(vector),
							 this.z.dotProduct(vector) );		
	}
	
	
	this.transpose = function() {
		var rtn = new Matrix3D();
		
		rtn.x.x = this.x.x;
		rtn.x.y = this.y.x;
		rtn.x.z = this.z.x;
		
		rtn.y.x = this.x.y;
		rtn.y.y = this.y.y;
		rtn.y.z = this.z.y;
		
		rtn.z.x = this.x.z;
		rtn.z.y = this.y.z;
		rtn.z.z = thix.z.z;
		
		return rtn;
		
	}
	
	this.scalarMul = function(scalar) {
		
		this.x.scale(scalar);
		this.y.scale(scalar);
		this.z.scale(scalar);
		
	}
	
	this.matMul = function( matrix ) {
		
		var rtn = new Matrix3D();
		var argument = matrix.transpose();
		
		rtn.x = new Vector( this.x.dotProduct(argument.x), this.x.dotProduct(argument.y), this.x.dotProduct(argument.z) );
		rtn.y = new Vector( this.y.dotProduct(argument.x), this.y.dotProduct(argument.y), this.y.dotProduct(argument.z) );
		rtn.z = new Vector( this.z.dotProduct(argument.x), this.z.dotProduct(argument.y), this.z.dorProduct(argument.z) );
		
		return rtn;
		
	}
	
	this.determinant = function() {
		
		var determinate = 0.0;
		
		determinate += this.x.x * ( (this.y.y * this.z.z) - (this.y.z * this.z.y) );
		determinate += this.x.y * ( (this.y.z * this.z.x) - (this.y.x * this.z.z) );
		determinate += this.x.z * ( (this.y.x * this.z.y) - (this.y.y * this.z.x) );
		
		return determinate;
	}
	
	this.toFloat32Array = function() {
		return new Float32Array([
			this.x.x,	this.x.y,	this.x.z,
			this.y.x,	this.y.y,	this.y.z,
			this.z.x,	this.z.y,	this.z.z
			])
	}
}
/*
 * Matrix4D : 4 dimensional matrix class with support operations
 */

function Matrix4D() {
	this.x = new Vector4D(0.0, 0.0, 0.0, 0.0);
	this.y = new Vector4D(0.0, 0.0, 0.0, 0.0);
	this.z = new Vector4D(0.0, 0.0, 0.0, 0.0);
	this.w = new Vector4D(0.0, 0.0, 0.0, 0.0);
	
	this.populateFromArray = function ( array ) {
		this.x = new Vector4D(array[0], array[1], array[2], array[3]);
		this.y = new Vector4D(array[4], array[5], array[6], array[7]);
		this.z = new Vector4D(array[8], array[9], array[10], array[11]);
		this.w = new Vector4D(array[12], array[13], array[14], array[15]);
	}
	
	this.rowVecMult = function(vector) {
		
		var rtn = new Vector4D( 0.0, 0.0, 0.0, 0.0 );
		
		rtn.x = vector.x * this.x.x + vector.y * this.y.x + vector.z * this.z.x + vector.w * this.w.x;
		rtn.y = vector.x * this.x.y + vector.y * this.y.y + vector.z * this.z.y + vector.w * this.w.y;
		rtn.z = vector.x * this.x.z + vector.y * this.y.z + vector.z * this.z.z + vector.w * this.w.z;
		rtn.w = vector.x * this.x.w + vector.y * this.y.w + vector.z * this.z.w + vector.w * this.w.w;
		
		return rtn;
	}
	
	this.colVecMult = function (vector) {
		return new Vector4D( this.x.dotProduct(vector),
							 this.y.dotProduct(vector),
							 this.z.dotProduct(vector),
							 this.w.dotProduct(vector) );
		
	}
	
	
	this.transpose = function() {
		var rtn = new Matrix4D();
		
		rtn.x = new Vector4D(this.x.x, this.y.x, this.z.x, this.w.x);
		rtn.y = new Vector4D(this.x.y, this.y.y, this.z.y, this.w.y);
		rtn.z = new Vector4D(this.x.z, this.y.z, this.z.z, this.w.z);
		rtn.w = new Vector4D(this.x.w, this.y.w, this.z.w, this.w.w);
		
		return rtn;
		
	}
	
	this.scalarMul = function(scalar) {
		
		this.x.scale(scalar);
		this.y.scale(scalar);
		this.z.scale(scalar);
		this.w.scale(scalar);
		
	}
	
	this.matMul = function( matrix ) {
		
		var rtn = new Matrix4D();
		var argument = matrix.transpose();
		
		rtn.x = new Vector4D( this.x.dotProduct(argument.x), this.x.dotProduct(argument.y), this.x.dotProduct(argument.z), this.x.dotProduct(argument.w) );
		rtn.y = new Vector4D( this.y.dotProduct(argument.x), this.y.dotProduct(argument.y), this.y.dotProduct(argument.z), this.y.dotProduct(argument.w) );
		rtn.z = new Vector4D( this.z.dotProduct(argument.x), this.z.dotProduct(argument.y), this.z.dotProduct(argument.z), this.z.dotProduct(argument.w) );
		rtn.w = new Vector4D( this.w.dotProduct(argument.x), this.w.dotProduct(argument.y), this.w.dotProduct(argument.z), this.w.dotProduct(argument.w) );
		
		return rtn;
		
	}
	
	this.determinant = function() {
		
		//use laplace expansion
		var rtn = 0.0;
		var subMatA = new Matrix3D();
		var subMatB = new Matrix3D();
		var subMatC = new Matrix3D();
		var subMatD = new Matrix3D();
		
		subMatA.populateFromArray([this.y.y, this.y.z, this.y.w,
								   this.z.y, this.z.z, this.z.w,
								   this.w.y, this.w.z, this.w.w]);
								   
		subMatB.populateFromArray([	this.x.y, this.x.z, this.x.w,
									this.z.y, this.z.z, this.z.w,
									this.w.y, this.w.z, this.w.w]);
		
		subMatC.populateFromArray([ this.x.y, this.x.z, this.x.w,
									this.y.y, this.y.z, this.y.w,
									this.w.y, this.w.z, this.w.w]);
		
		subMatD.populateFromArray([	this.x.y, this.x.z, this.x.w,
									this.y.y, this.y.z, this.y.w,
									this.z.y, this.z.z, this.z.w]);
		
		rtn = this.x.x * (subMatA.determinant()) - this.y.x * (subMatB.determinant()) + this.z.x * (subMatC.determinant()) - this.w.x * (subMatD.determinant());
		return rtn;
	}
	
	//more tedious than working with the windows api. 
	this.inverse = function() {
		var rtn = new Matrix4D();
		var scale = this.determinant()
		scale = 1.0/scale;
		
	    rtn.x.x = this.y.z*this.z.w*this.w.y - this.y.w*this.z.z*this.w.y + this.y.w*this.z.y*this.w.z - this.y.y*this.z.w*this.w.z - this.y.z*this.z.y*this.w.w + this.y.y*this.z.z*this.w.w;
	    rtn.x.y = this.x.w*this.z.z*this.w.y - this.x.z*this.z.w*this.w.y - this.x.w*this.z.y*this.w.z + this.x.y*this.z.w*this.w.z + this.x.z*this.z.y*this.w.w - this.x.y*this.z.z*this.w.w;
	    rtn.x.z = this.x.z*this.y.w*this.w.y - this.x.w*this.y.z*this.w.y + this.x.w*this.y.y*this.w.z - this.x.y*this.y.w*this.w.z - this.x.z*this.y.y*this.w.w + this.x.y*this.y.z*this.w.w;
	    rtn.x.w = this.x.w*this.y.z*this.z.y - this.x.z*this.y.w*this.z.y - this.x.w*this.y.y*this.z.z + this.x.y*this.y.w*this.z.z + this.x.z*this.y.y*this.z.w - this.x.y*this.y.z*this.z.w;
	    rtn.y.x = this.y.w*this.z.z*this.w.x - this.y.z*this.z.w*this.w.x - this.y.w*this.z.x*this.w.z + this.y.x*this.z.w*this.w.z + this.y.z*this.z.x*this.w.w - this.y.x*this.z.z*this.w.w;
	    rtn.y.y = this.x.z*this.z.w*this.w.x - this.x.w*this.z.z*this.w.x + this.x.w*this.z.x*this.w.z - this.x.x*this.z.w*this.w.z - this.x.z*this.z.x*this.w.w + this.x.x*this.z.z*this.w.w;
	    rtn.y.z = this.x.w*this.y.z*this.w.x - this.x.z*this.y.w*this.w.x - this.x.w*this.y.x*this.w.z + this.x.x*this.y.w*this.w.z + this.x.z*this.y.x*this.w.w - this.x.x*this.y.z*this.w.w;
	    rtn.y.w = this.x.z*this.y.w*this.z.x - this.x.w*this.y.z*this.z.x + this.x.w*this.y.x*this.z.z - this.x.x*this.y.w*this.z.z - this.x.z*this.y.x*this.z.w + this.x.x*this.y.z*this.z.w;
	    rtn.z.x = this.y.y*this.z.w*this.w.x - this.y.w*this.z.y*this.w.x + this.y.w*this.z.x*this.w.y - this.y.x*this.z.w*this.w.y - this.y.y*this.z.x*this.w.w + this.y.x*this.z.y*this.w.w;
	    rtn.z.y = this.x.w*this.z.y*this.w.x - this.x.y*this.z.w*this.w.x - this.x.w*this.z.x*this.w.y + this.x.x*this.z.w*this.w.y + this.x.y*this.z.x*this.w.w - this.x.x*this.z.y*this.w.w;
	    rtn.z.z = this.x.y*this.y.w*this.w.x - this.x.w*this.y.y*this.w.x + this.x.w*this.y.x*this.w.y - this.x.x*this.y.w*this.w.y - this.x.y*this.y.x*this.w.w + this.x.x*this.y.y*this.w.w;
	    rtn.z.w = this.x.w*this.y.y*this.z.x - this.x.y*this.y.w*this.z.x - this.x.w*this.y.x*this.z.y + this.x.x*this.y.w*this.z.y + this.x.y*this.y.x*this.z.w - this.x.x*this.y.y*this.z.w;
	    rtn.w.x = this.y.z*this.z.y*this.w.x - this.y.y*this.z.z*this.w.x - this.y.z*this.z.x*this.w.y + this.y.x*this.z.z*this.w.y + this.y.y*this.z.x*this.w.z - this.y.x*this.z.y*this.w.z;
	    rtn.w.y = this.x.y*this.z.z*this.w.x - this.x.z*this.z.y*this.w.x + this.x.z*this.z.x*this.w.y - this.x.x*this.z.z*this.w.y - this.x.y*this.z.x*this.w.z + this.x.x*this.z.y*this.w.z;
	    rtn.w.z = this.x.z*this.y.y*this.w.x - this.x.y*this.y.z*this.w.x - this.x.z*this.y.x*this.w.y + this.x.x*this.y.z*this.w.y + this.x.y*this.y.x*this.w.z - this.x.x*this.y.y*this.w.z;
	    rtn.w.w = this.x.y*this.y.z*this.z.x - this.x.z*this.y.y*this.z.x + this.x.z*this.y.x*this.z.y - this.x.x*this.y.z*this.z.y - this.x.y*this.y.x*this.z.z + this.x.x*this.y.y*this.z.z;
		
		rtn.scalarMul(scale);
		return rtn;
	}
	
	this.toFloat32Array = function() {
		return new Float32Array([
				this.x.x,	this.x.y,	this.x.z, 	this.x.w,
				this.y.x,	this.y.y,	this.y.z,	this.y.w,
				this.z.x,	this.z.y,	this.z.z,	this.z.w,
				this.w.x,	this.w.y,	this.w.z,	this.w.w
			])
	}

	this.copy = function() {
		var rtn = new Matrix4D();
		rtn.x = this.x.copy();
		rtn.y = this.y.copy();
		rtn.z = this.z.copy();
		rtn.w = this.w.copy();
		return rtn;
	}
	
}


/*
 * Support Functions
 * 
 * Mandelbrotify : Recursively operates on mset until convergence (or lack there of) is achieved.
 * 
 * generateMSet  : Populates the initial mandebrot values
 */


function Mandelbrotify() {
	
	var iterations = 0;
	
	for(var x = 1; x < mSet.length; ++x) {
		for(var y = 1; y < mSet[y].length; ++y) {
			
			//establish C and initial Z
			baseline_Mandel = mSet[x][y].copy();
			(mSet[x][y]).rComp = 0.0;
			(mSet[x][y]).iComp = 0.0;
			
			while( mSet[x][y].modSquare() < rMax && ( iterations < MAX_HEIGHT ) ) {
				
				
				//Z(n+1) = Z(n) * z(n) + c
				
				mSet[x][y] = (mSet[x][y].mult(mSet[x][y])).add(baseline_Mandel);
				iterations++;
			}
			
			//determine outcome and assign value
			var decisionVar = mSet[x][y].modSquare(); 
			if (decisionVar > rMax) {
				mSet[x][y] = iterations;
			}
			else{
				mSet[x][y] = 0;
			}
			
			iterations = 0;
		}
	}
	
}

function generateMSet(xMax, yMax, 
					  nleft, nright, nbottom, ntop) {

	if(typeof nleft   === 'undefined'  ||
	   typeof nright  === 'undefined'  ||
	   typeof nbottom === 'undefined'  ||
	   typeof ntop    === 'undefined'    ) {
		console.log("Error, not all values set");
		return;
	}

	//store vars for future calculations

	left = nleft;
	right = nright;
	bottom = nbottom;
	topVal = ntop;
				  	
	//Generate Map
	mSet = []
	for(var index = 0; index < xMax + 1; ++index) {
		mSet.push(new Array());
	}
	
	baseline_Mandel = new Complex();
	baseline_Mandel.iComp = ntop;
	baseline_Mandel.rComp = nleft;
	var complexNum = baseline_Mandel.copy();
	
	//Calculate Deltas
	var dx = (right - left) / (xMax - 1)
	var dy = (topVal - bottom) / (yMax - 1)
	
	
	for (var xInd = 1; xInd < xMax+1; ++xInd) {
		mSet[xInd].push(undefined)
		for (var yInd = 1; yInd < yMax+1; ++yInd) {
			
			var temp = complexNum.copy();
			mSet[xInd].push(temp);
			complexNum.iComp = complexNum.iComp - dy;
		}
		
		//reestablish baseline
		complexNum.iComp = ntop;
		complexNum.rComp = complexNum.rComp + dx;
		
	}
}

/*
 * initBuffers serves to initialize the buffers, but can also be used to flush them in a pinch
 */

function initBuffers() {
	vBuffer = gl.createBuffer();
	cBuffer = gl.createBuffer();
	
	//init vertex buffer
	gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer);
	gl.bufferData(gl.ARRAY_BUFFER, 12 * MAX_POINTS, gl.STATIC_DRAW);
	
	vPosition = gl.getAttribLocation(program, "vPosition");
	gl.vertexAttribPointer(vPosition, 3, gl.FLOAT, false, 0, 0);
	gl.enableVertexAttribArray(vPosition);
	
	//normal buffer and attrib
	nBuffer= gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, nBuffer);
	gl.bufferData(gl.ARRAY_BUFFER, 12 * MAX_POINTS, gl.STATIC_DRAW);
	
	vNormal   = gl.getAttribLocation(program, "vNormal");
	gl.vertexAttribPointer(vNormal, 3, gl.FLOAT, false, 0, 0);
	gl.enableVertexAttribArray(vNormal);
	
	
	
}


function transform() {

	/*
	 * Obj -> World Translation
	 */

	//translate
	var transformation = makeTranslation3D((-1 * xDim/2.0) + 0.5, (-1 * yDim/2.0) + 0.5, 0.0);
	var operand = new Matrix4D();
	var transMatrix = new Matrix4D();
	transMatrix.populateFromArray(transformation);
	

	
	
	//scale
	var sX = 510.0 / xDim - 1.0;
	var sY = 510.0 / yDim - 1.0;
	var sZ = 1.0
	transformation = makeScale3D( sX, sY, sZ );
	var operand = new Matrix4D();
	operand.populateFromArray(transformation);
	transMatrix = transMatrix.matMul(operand);
	
	//vertices are now in world coordinates, setting up camera view and scaling to canvas
	
	//orient for isometric view
	
	//rotate on Z to swing camers to <1,1,1>
	transformation = makeRotation3DZ(-2.35619449);
	operand.populateFromArray(transformation);
	transMatrix = transMatrix.matMul(operand);
	
	
	//rotate on z by 45 degrees  
	                   	
	transformation = makeRotation3DX(-Math.PI/4.0);  
	operand.populateFromArray(transformation);      
	transMatrix = transMatrix.matMul(operand);      
	
	
	//scale to clip coordinates
	transformation = makeScale3D(1.8/510, 1.8/510, 0.8/255);
	operand.populateFromArray(transformation);
	transMatrix = transMatrix.matMul(operand);
	
	//set this matrix as gl uniform
	var projMat = gl.getUniformLocation(program, "projectionMat");
	gl.uniformMatrix4fv(projMat, false, transMatrix.toFloat32Array());	
	
	//set normal matrix, initialize unform matrix
	var uNorm = new Matrix4D();
	uNorm = (transMatrix.inverse()).transpose();
	var normMat = gl.getUniformLocation(program, "normalMat");
	var test = uNorm.toFloat32Array();
	gl.uniformMatrix4fv(normMat, false, uNorm.toFloat32Array() );
	
	//set light source and use this data to initialize the uniform float
	var lightSource = new Vector4D(1.0, 1.0, 1.0, 0.0);
	gl.uniform4fv(gl.getUniformLocation(program, "lightPosition"), lightSource.toFloat32Array());
	
	
}

/*
 * generate is a function utilized to capture user entered values from the html side of the application
 */
function generate() {
	initBuffers();
	var formData = document.getElementById("frm1").elements;
	
	if(parseFloat(formData[0].value) > MAX_XDIM || parseFloat(formData[1].value) > MAX_YDIM) {
		alert("Error : Exceeding maximum xDim or yDim");
		return
	}
	
	xDim = parseFloat(formData[0].value);
	yDim = parseFloat(formData[1].value);
	left = parseFloat(formData[2].value);
	right = parseFloat(formData[3].value);
	bottom = parseFloat(formData[4].value);
	topVal = parseFloat(formData[5].value);
	
	//generate Mandelbrot set
	generateMSet(xDim, yDim, left, right, topVal, bottom);
	Mandelbrotify();
	transform();
	render();
	
}

/*
 * render uses the set of mandelbrot coordinates to generate a set of quads.
 * 
 * this could be made more efficient by finding a way to eliminate redunant operations on interior vertices
 */

function render() {
	//render
	gl.clear( gl.COLOR_BUFFER_BIT);
	var pointCount = 0;
	gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer);
	
	for(var xI = 1; xI < mSet.length - 1; ++xI) {
		for(var yI = 1; yI < mSet[xI].length - 1; ++ yI) {
			
			//generate the four points of a quad from the set of mandlebrot points,
			
			var pointA = new Vector(xI, yI, mSet[xI][yI]);
			var pointB = new Vector(xI + 1, yI, mSet[xI + 1][yI]);
			var pointC = new Vector(xI + 1, yI + 1, mSet[xI + 1][yI + 1]);
			var pointD = new Vector(xI, yI + 1, mSet[xI][yI + 1]);
			
			//get normals
			
			// Tri 1
			var vecBA = pointA.add( pointB.scalarMult(-1) );
			var vecBC = pointC.add( pointB.scalarMult(-1) );
			var normTriOne = vecBC.crossProduct(vecBA);
			
			
			//Tri 2
			var vecDA = pointA.add( pointD.scalarMult(-1) );
			var vecDC = pointC.add( pointD.scalarMult(-1) );
			var normTriTwo = vecDA.crossProduct(vecDC);
			
			//these three points are tris
			//devide them and calculate the n
			
			
			//buffer this vertex data into the vBuffer
			//cackle maniacally as this occurs for effect
			gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer);
			gl.bufferSubData(gl.ARRAY_BUFFER, 12 * pointCount, pointA.toFloat32Array() );
			pointCount++;
			gl.bufferSubData(gl.ARRAY_BUFFER, 12 * pointCount, pointB.toFloat32Array() );
			pointCount++;
			gl.bufferSubData(gl.ARRAY_BUFFER, 12 * pointCount, pointC.toFloat32Array() );
			pointCount++;
			
			//Second Tri
			gl.bufferSubData(gl.ARRAY_BUFFER, 12 * pointCount, pointC.toFloat32Array() );
			pointCount++;
			gl.bufferSubData(gl.ARRAY_BUFFER, 12 * pointCount, pointD.toFloat32Array() );
			pointCount++;
			gl.bufferSubData(gl.ARRAY_BUFFER, 12 * pointCount, pointA.toFloat32Array() );
			pointCount++
			
			//normals
			gl.bindBuffer(gl.ARRAY_BUFFER, nBuffer);
			for (var index = pointCount - 6 ; index < pointCount - 3; ++index) {
				gl.bufferSubData(gl.ARRAY_BUFFER, 12 * index, normTriOne.toFloat32Array() );
				gl.bufferSubData(gl.ARRAY_BUFFER, 12 * (index+3), normTriTwo.toFloat32Array() );
			}
			
			//Change to gl.triangles
			gl.drawArrays(gl.TRIANGLES, pointCount - 6, 3 );
			gl.drawArrays(gl.TRIANGLES, pointCount - 3 ,3 );
			
			
		}
	}
}

/*
 * init sets up and compiles the shaders and initializes the GL context
 */

window.onload = function init() {
	rMax = 100;
	MAX_HEIGHT = 255;
	
	//compile gl shaders
		//fragment shader, assign all verts white

	
	//vertex shader, no longer passthrough
	//this has a uniform 4D matrix that will be applied to vertices processed
	//in this pipeline.
	vShader = [
		"attribute vec4 vPosition;",
		"attribute vec4 vNormal;",
		
		"varying vec4 fColor;",
		
		"uniform mat4 projectionMat;",
		"uniform mat4 normalMat;",
		"uniform vec4 lightPosition;",
		
		"void",
		"main()",
		"{",
			
			
			"gl_PointSize = 1.0;",
    		"gl_Position = projectionMat * vPosition;",
			
			"vec3 pos = (projectionMat * vPosition).xyz;",
			"vec3 light = lightPosition.xyz;",
			
			"vec3 pos_to_light = normalize(light - pos);",
			"vec3 pos_norm = normalize(normalMat * vNormal).xyz;",
			"float cos_angle = dot(pos_to_light, pos_norm);",
			
			
			"vec4 tri_color = vec4(0.0, 1.0, 0.0, 1.0);",
			"fColor = cos_angle * tri_color;",
			"fColor.a = 1.0;",
			
    		/*
    		//Triangle constants
    		//if light color is white, (1.0, 1.0, 1.0, 1.0)
    		//there is no need to store it, since it's combination
    		//with the tri_color will simply be the tri_color
    		
    		"vec4 tri_color = vec4(0.0, 0.6, 0.0, 1.0);",
			"vec4 newNorm = normalize(normalMat * vNormal);",
    		
    		"vec4 lightPosition = vec4(1.0, 1.0, 1.0, 0.0);",
    		"vec4 pos = (projectionMat * vPosition);",
    		"vec4 pos_to_light = normalize(pos + lightPosition);",
    		
    		//Dot product will return the cosine of the angle
    		"float cos_angle = dot(newNorm, pos_to_light);",
    		"fColor = cos_angle * tri_color;",
			*/
    		
    		
		"}",
	].join('\n');
	
	fShader = [
		"precision mediump float;",
		"varying vec4 fColor;",
		"void",
		"main()",
		"{",
   			"gl_FragColor = fColor;",
		"}",
	].join('\n');
	
	//arbitrary maxes to 
	MAX_XDIM = 160;
	MAX_YDIM = 120;
	MAX_POINTS = 125000;
	
	
	//initialize gl
	
	
	canvas = document.getElementById( "gl-canvas" )
	
	
	gl = WebGLUtils.setupWebGL( canvas );
	if ( !gl ) { alert( "WebGL isn't available" ); }
	
	//tell gl to do depth comparisons and update the depth buffer.
	gl.enable(gl.DEPTH_TEST);
	
	//adjust the viewport to cover the entirity of the canvas from (0,0) to upper right
	gl.viewport(0, 0, canvas.width, canvas.height);
	
	//set the clear bit
	gl.clearColor( 0.0, 0.0, 0.0, 1.0 );
	
	//compie shaders
    program = initShaders(gl, vShader, fShader);
    gl.useProgram( program );
	
	
	initBuffers();
	
	//render a blank screen to prepare for generation
	gl.clear( gl.COLOR_BUFFER_BIT);
	
	
}
